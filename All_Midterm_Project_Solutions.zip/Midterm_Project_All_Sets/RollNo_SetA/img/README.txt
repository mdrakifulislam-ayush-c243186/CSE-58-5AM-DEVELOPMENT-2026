Place local project images here. The demo remains functional without them.
